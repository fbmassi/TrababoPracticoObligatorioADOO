package interfaces;
import model.socio.*;

public interface IObserver {

    void serNotifocadoPor(IObservable observable);

}
