package interfaces;

import model.socio.Socio;

import java.util.List;

public interface IMedidorAdapter {

    List<Float> medirEstadoFisico(Socio socio);

}
