package model.ejercicios;

public enum Estado {
    NO_INICIADO,
    INICIADO,
    FINALIZADO
}
