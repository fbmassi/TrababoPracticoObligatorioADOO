package model.ejercicios;

public enum NivelExigencia {
    ALTA,
    MEDIA,
    BAJA
}
