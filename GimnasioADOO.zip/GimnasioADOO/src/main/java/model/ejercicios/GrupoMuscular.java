package model.ejercicios;

public enum GrupoMuscular {
    PECHO,
    ESPALDA,
    HOMBRO,
    PIERNAS,
    BRAZOS
}
